﻿/* About Bool64
* - What it is?
*  Bool64 is a planned library project that adds a new types of variables. 
* These variables act as a flag system that propery used can optimize 
* original bool type use.
* 
*  To start with let me remind you what bool is.
* The boolean type is an 8-bit type which can have a value of -127 up to 127.
* However we only need to know if it's either a 0 or anything else.
* So u propably wondering why bool haven't got replaced by something that might be
* simply just 1 or a 0 just like bit.
* 
*  The answer to this is that we do not only care about our RAM but also about our processor
* the RAM cannot simply move by one bit when reading data from itself...
* and the processor apparentry can indeed work on 8bit, 16bit, 32bit, 64bit intigers
* and actually some instructions like SIMD can work with 128bit as well as with 256bit intigers.
* However what happens (i guess maybe not in all casses) is that the 8bit type is being
* extended by additional 56bits on load from memory and when
* on store the 56bits are being discarded. This means we're not actually loosing in the clock speed,
* #ref https://www.reddit.com/r/C_Programming/comments/hd8cuh/in_a_x64_architecture_how_is_a_unit8_t_array/
* but we could use those bits somewhat.
* 
*  - x86-64 architecture (i guess everything can happend https://en.wikipedia.org/wiki/X86-64)
*  - 
* 
* - How to use it?
* - Where to use it?
*/

/* try catch
* i ve done  a small test on the debugger and it seems that indeed try catch generetas way more code then an if statement.
* i wonder if exceptions could look somewhat better and at what level they exist.
* if there would be a way to make an a exception throw somewhat readable by future code easier it would be great
* it makes seense to me that there should be a system that would flicker without use of an if statement.
* because we know what we're dealing with. I know i am gonna get an exception then why do i check for it instead of knowingly have a 2 path build in.
* 
* Because if there would be a way like:
*  like if certain bits had a different voltage it could be simpler to change the output of the operation in it.
*  everything is better then cheking if the value is the value. but to do so these bites have to have properties that can quickly interupt the normal execution. 
* 
*  maybe if there would be a system of two actions where one action gets executed it turns off and the action 2 turns on and the next operation executes on action 2.
*  the second action would be ...
* 
*  maybe if there would be something like devision and rest. but we would have the result and flag instead.
*  oh i am going nowhere.
*/

/* ToDo:
* 1. Seperate it into files.
*  - 64bit, 32bit compilation : I honestly don't know if i care about 32bit
*  - bool64 API
*  - other defines and types and API
* 2. 64bit MASM file.
* 3. Create a folder structure inside solution:
*  - cpp folder
*  - hpp folder
*  - asm folder
*  - obj maybe to
* 4. See if "#define block inline void" and API syntax corection and such around it is possible.
* 5. See, rewrite if needed the #define forever keyword (see if it compiles to goto statement)
*/

// https://docs.microsoft.com/en-us/cpp/intrinsics/bittestandreset-bittestandreset64?view=msvc-160
// https://www.codeproject.com/Articles/11037/Using-Assembly-routines-in-Visual-C

#include "bool64.h"
#include <intrin.h>

// nodiscard thingy
struct Sample1 {
    [[nodiscard("This function only retrives information why would you discard it.")]]
    bool func1() {
        return true;
    }
};

struct [[nodiscard("This struct exists to only retrive information")]] Sample2 {
    
};

// https://stackoverflow.com/questions/1505582/determining-32-vs-64-bit-in-c
// Check Windows
#if _WIN32 || _WIN64
    #if _WIN64
        #define ENV64BIT
        static_assert(sizeof(void*) == 8, "Error: The Arch is not what I think it is");
    #else
        #define ENV32BIT
        static_assert(sizeof(void*) == 4, "Error: The Arch is not what I think it is");
    #endif
#endif

// Check GCC
#if __GNUC__
    #if __x86_64__ || __ppc64__
        #define ENV64BIT
        static_assert(sizeof(void*) == 8, "Error: The Arch is not what I think it is");
    #else
        #define ENV32BIT
        static_assert(sizeof(void*) == 4, "Error: The Arch is not what I think it is");
    #endif
#endif

#define forever while(1)

using bool64 = std::uint64_t;
using boolMask64 = bool64;

using bool32 = std::uint32_t;
using boolMask32 = bool32;

// /int SampleDivideByZero(int a, int b) {
// /    try {
// /        a /= b;
// /        return a;
// /    } catch (const std::exception& e) {
// /        return b;
// /    }
// /}

//int func32(long* p) {
//    const int sign_bit = 31;
//    return _bittestandreset(p, 1);
//}

//int func64(long long* p) {
//    const int sign_bit = 31;
//    return _bittestandreset64(p, 1);
//}

// About /SAFESH:
// https://social.msdn.microsoft.com/Forums/en-US/ec2b66ec-f1a3-49fb-a8df-329965239284/safeseh-and-assembler-code?forum=vcgeneral
#if defined(ENV32BIT) 
    extern "C" int __stdcall SetBits(int, int, int); 
#endif

int main() {
    const boolMask64 mask = 
        0b1000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'1000'0000;
    bool64 collection =
        0b0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000;

    //const boolMask32 mask =
    //    0b1000'0000'0000'0000'0000'0000'0000'0000;
    //bool32 collection =
    //    0b0000'0000'0000'0000'0000'0000'0000'0000;

    // / int a = 5, b = 3, c = 0;
    // / c = SampleDivideByZero(5, 3);

    //_bittestandreset64(&collection, 1);
    //int result = 0;

    //_asm {
    //    mov eax, 5
    //    add eax, 10
    //    add eax, 15
    //    mov result, eax
    //}
    //result = 1 / 0;
    //std::cout << result << '\n';


    //int a = SetBits(1, 2, 3);
    //std::cout << a;


    //collection |= mask;

    //func64(&collection);

    // SetTrue
    //collection |= mask;

    // SetFalse
    //collection &= ~mask;

    // Flip
    //collection ^= mask;

    //forever {
    //    std::cin >> a;
    //}

    //std::cout << "Hello World!\n";
    //return 0;
}

//struct bool64;

/* VS 2019 notification 
// Uruchomienie programu: Ctrl + F5 lub menu Debugowanie > Uruchom bez debugowania
// Debugowanie programu: F5 lub menu Debugowanie > Rozpocznij debugowanie

// Porady dotyczące rozpoczynania pracy:
//   1. Użyj okna Eksploratora rozwiązań, aby dodać pliki i zarządzać nimi
//   2. Użyj okna programu Team Explorer, aby nawiązać połączenie z kontrolą źródła
//   3. Użyj okna Dane wyjściowe, aby sprawdzić dane wyjściowe kompilacji i inne komunikaty
//   4. Użyj okna Lista błędów, aby zobaczyć błędy
//   5. Wybierz pozycję Projekt > Dodaj nowy element, aby utworzyć nowe pliki kodu, lub wybierz pozycję Projekt > Dodaj istniejący element, aby dodać istniejące pliku kodu do projektu
//   6. Aby w przyszłości ponownie otworzyć ten projekt, przejdź do pozycji Plik > Otwórz > Projekt i wybierz plik sln
*/