﻿// CppConcepts.cpp : Ten plik zawiera funkcję „main”. W nim rozpoczyna się i kończy wykonywanie programu.
//

/* ToDo
* 1. Inlining and Debugging. I simply don't know if my functions get inlined or not.
*  // inlinowanie trochę mnie zatrzymało potrzebuje wiedzieć czy funkcja się inlajunje żeby dalej spokojnie rozw. kod.
* 2. >> & << functionality
* 3. sum of 2 bool64 functionality
* 4. sum of bool64 and int functionality
* 5. good exaples just plan this shit out. and do expamples one by one.
*/

/* Conslusions
* It appears that bool64 might be better only whenever we need to declare and operate at more then 1 boolean at the same time.
* Simply saying operations like "ands", "ors", "xors" and shifts requires at least 3 operations to change boolean type wheras bool can be either be set to true or false. (1 operation).
*/

/* Desassembly
* F11, Ctrl+k -> g.
*/

/* Links
* https://docs.microsoft.com/en-us/windows-hardware/drivers/debugger/debugging-optimized-code-and-inline-functions-external
* https://docs.microsoft.com/en-us/windows-hardware/drivers/debugger/debugging-in-assembly-mode
* https://stackoverflow.com/questions/308364/c-bitfield-packing-with-bools 
* - bitfields : how does they look in processor the same as in ram or..
* https://stackoverflow.com/questions/43491737/compiler-generates-costly-movzx-instruction
* - something about different move operations i guess with registers and without, theres also some more.
*/

#include <iostream>
#include <cstdint>


// Bool, Bitfield, Flags.
// Theres many more but whats the best for you to 
// just fit in your 64bit processor and work without any trimming.
//namespace flags {
//    // first lets try to fit in 1byte then we're move to 32 and maybe later to 64.
//    using namespace std;
//
//    constexpr uint_fast64_t sample{ 0b0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000 };
//
//    constexpr uint_fast8_t mask0{ 0b0000'0001 }; // bit 0
//    constexpr uint_fast8_t mask1{ 0b0000'0010 }; // bit 1
//    constexpr uint_fast8_t mask2{ 0b0000'0100 }; // bit 2
//    constexpr uint_fast8_t mask3{ 0b0000'1000 }; // bit 3
//    constexpr uint_fast8_t mask4{ 0b0001'0000 }; // bit 4
//    constexpr uint_fast8_t mask5{ 0b0010'0000 }; // bit 5
//    constexpr uint_fast8_t mask6{ 0b0100'0000 }; // bit 6
//    constexpr uint_fast8_t mask7{ 0b1000'0000 }; // bit 7
//
//}

// think how to ensure use of registers insted of ram
// SetTrue
// SetFalse
// Flip

// make use of '<<' and '>>' maybe a special type like tasklist or something.

// remember that bits can be set using multiple masks

// tak boolean wymyślił [prawda/fałsz] a nie typ bool 
// więc mogę to nazwać bool :)

// rozdzielić myśleniem na operacje processora i zapisywanie w pamięci. 64x64

//namespace masks { // alternative name 8unit_bool
//    // its actually quite readable because u can always define things like so: isWarrior = 0, isHungry = 1. so the array ain't the prob.
//    const uint_fast8_t fullByte = { 0b1111'1111 };
//    const uint_fast8_t byte[8] = { 
//        0b0000'0001, // 1 bit
//        0b0000'0010, // 2 bit
//        0b0000'0100, // 3 bit
//        0b0000'1000, // 4 bit
//        0b0001'0000, // 5 bit
//        0b0010'0000, // 6 bit
//        0b0100'0000, // 7 bit
//        0b1000'0000  // 8 bit
//    };
//}

//#define isHungry 0b0000'0000'0000'0000'0000'0000'1000'0000

struct bool64 {
    using boolMask = std::uint_fast64_t;
    using val = std::uint_fast64_t;

    val value;

    __declspec(noinline) val setFalse(boolMask mask) {
        return value | mask;
    }

    __forceinline val setTrue(boolMask mask) {
        return value & ~mask;
    }

    inline val flip(boolMask mask) {
        return value ^ mask;
    }
};

// flags {
//    using boolMask = std::uint_fast64_t;
//    using bool64 = std::uint_fast64_t;
//
//    inline bool64 setFalse(bool64 boolean, boolMask mask) {
//        return boolean | mask;
//    }
//
//    inline bool64 setTrue(bool64 boolean, boolMask mask) {
//        return boolean & ~mask;
//    }
//
//    inline bool64 flip(bool64 boolean, boolMask mask) {
//        return boolean ^ mask;
//    }
//}

int theBoolConcept() {
    char ahh;
    std::cin >> ahh;
    std::uint_fast64_t worker = { 0b1000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000 };
    const std::uint_fast64_t state = { 0b0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'1000'0000 };
    //std::uint_fast32_t worker = { 0b0000'0000'0000'0000'0000'0000'0000'0000 };
    //const std::uint_fast32_t state = { 0b0000'0000'0000'0000'0000'0000'1000'0000 };

    // SetTrue
    worker |= state;

    // SetFalse
    worker &= ~state;

    // Flip
    worker ^= state;

    return 0;
}

int boolSample() {
    bool sample = false;
    bool samplr = true;

    sample = true;
    samplr = false;

    sample = false;
    samplr = true;
    //sample = ~sample;
    //sample = ~sample;

    // here
    //std::cerr << sample;

    return 0;
}

int main() {
    std::string output = "Hello! This project is all about showcasing optimalizations that can be used.\n";
    std::cout << output;
    //int sample;

    //if(theBoolConcept() == 0);
    //    boolSample();

    bool64::boolMask boolMaskSample = { 0b0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'1000'0000 };
    bool64 sample;
    sample.value = { 0b0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000 };

    //std::cin >> boolMaskSample;

    sample.setFalse(boolMaskSample);
    sample.setTrue(boolMaskSample);
    sample.flip(boolMaskSample);

    //std::cout << sample.value;


    //using namespace flags;
    //boolMask maskSample = { 0b0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'1000'0000 };
    //bool64 boolSample = { 0b0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000'0000 };

    // SetFalse
    //setFalse(boolSample, maskSample);

    // SetTrue
    //setTrue(boolSample, maskSample);

    // Flip
    //flip(boolSample, maskSample);

    //std::cout << ((boolSample & maskSample) ? "on\n" : "off\n");
    
    
    //constexpr std::uint_fast8_t sample1 = { 0b0000'0010 };
    //worker ^= sample1;

    //std::uint_fast8_t sample2 = { 0b0000'0001 };
    //sample2 <<= 7;
    //worker ^= sample2;

    //std::cout << "bit 2 is: " << ((worker & sample2) ? "on\n" : "off\n");


    //uint_fast8_t sample_flags{ 0b0000'0101 };
    //std::cout << sizeof(long long);

    //using namespace flags;
    // conjuction
    //std::cout << "bit 2 is: " << ((sample_flags & mask2) ? "on\n" : "off\n");
    //sample_flags ^= mask2;
    //std::cout << "bit 2 is: " << ((sample_flags & mask2) ? "on\n" : "off\n");

    return 0;
}

/* the idea is:
 * 1. Bool takes up the space of 256 bits and it's a trimmed 64b
 * 
 */


// o tyle koncept bool array jest ciekawy.
// że pozwoliłby mi on ustawianie / zmienianie kilku wartości na raz. 