// Mathhew's Strumillo Types library.
//

#pragma once
#include <cstdint>

namespace mst {

	using UINT64 = uint64_t; // Unsigned Intigier 64bit.
	using UINT32 = uint32_t; // Unsigned Intigier 32bit.
	using UINT16 = uint16_t; // Unsigned Intigier 16bit.
	using UINT8	 = uint8_t;  // Unsigned Intigier 8bit.
	using INT64 = int64_t; // Signed Intigier 64bit.
	using INT32 = int32_t; // Signed Intigier 32bit.
	using INT16 = int16_t; // Signed Intigier 16bit.
	using INT8  = int8_t;  // Signed Intigier 8bit.

	using UCHAR32 = char32_t; // Unsigned Character 32bit.
	using UCHAR16 = char16_t; // Unsigned Character 32bit.

	using REAL64 = double; // Floating Point Unit 64bit.
	using REAL32 = float;  // Floating Point Unit 32bit.
}