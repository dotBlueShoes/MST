﻿// mst-sample.cpp : Ten plik zawiera funkcję „main”. W nim rozpoczyna się i kończy wykonywanie programu.
//

#include <iostream>
#include "mst.hpp"

using namespace mst;

int main() {
    std::cout << "Hello World!\n";
    unsigned INT32 sample = 20;
}
